package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories;

import java.time.LocalDate;
import java.sql.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Factura;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.Letra;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_FacturaRepository;

@Repository
public class FacturaRepository implements I_FacturaRepository {

    // private Letra letra;
    // private Integer numero;
    // private LocalDate fecha;
    // private double precioFinal;
    // private Integer idCliente;

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO facturas (letra, numero, fecha, precioFinal, idCliente) VALUES (?,?,?,?,?)";
    private static final String SQL_FIND_BY_LETRA_NUMERO =
        "SELECT * FROM facturas WHERE letra=? and numero=?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM facturas";
    private static final String SQL_UPDATE =
        "UPDATE facturas SET fecha=?, precioFinal=?, idCliente=? WHERE letra=? and numero=?";
    private static final String SQL_DELETE =
        "DELETE FROM facturas WHERE letra=? and numero=?";
    private static final String SQL_FIND_BY_FECHA =
        "SELECT * FROM facturas WHERE fecha=?";

    public FacturaRepository(DataSource dataSource){
        this.dataSource=dataSource;
    }

    @Override
    public void create(Factura factura) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE)) {
            ps.setString(1, factura.getLetra().name());       
            ps.setInt(2, factura.getNumero());
            ps.setDate(3, Date.valueOf(factura.getFecha()));
            ps.setDouble(4, factura.getPrecioFinal());
            ps.setInt(4, factura.getIdCliente());
            ps.executeUpdate();
             
        }
    }

    @Override
    public Factura findByIdLetraNumero(Letra letra, int numero) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_LETRA_NUMERO)) {
            ps.setString(1, letra.name());
            ps.setInt(2, numero);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            } 
        } 
        return null;
    }

    @Override
    public List<Factura> findAll() throws SQLException {
        List<Factura> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while(rs.next()){
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(Factura factura) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setDate(1, Date.valueOf(factura.getFecha()));
            ps.setDouble(2, factura.getPrecioFinal());
            ps.setInt(3, factura.getIdCliente());
            ps.setString(4, factura.getLetra().name());
            ps.setInt(5, factura.getNumero());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public int delete(Letra letra, int numero) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setString(1, letra.name());
            ps.setInt(1, numero);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<Factura> findByFecha(LocalDate fecha) throws SQLException {
        List<Factura> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_FECHA)) {
            ps.setDate(1, Date.valueOf(fecha));
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
    }

    private Factura mapRow(ResultSet rs) throws SQLException{
        Factura f = new Factura();
        f.setLetra(Letra.valueOf(rs.getString("letra")));
        f.setNumero(rs.getInt("numero"));
        f.setFecha(rs.getDate("fecha").toLocalDate());
        f.setPrecioFinal(rs.getDouble("precio final")); 
        f.setIdCliente(rs.getInt("idCliente"));
        return f; 
    }

}
