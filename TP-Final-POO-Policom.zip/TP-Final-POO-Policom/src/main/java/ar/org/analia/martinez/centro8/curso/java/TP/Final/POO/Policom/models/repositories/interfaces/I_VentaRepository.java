package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Venta;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.Letra;

public interface I_VentaRepository {

    void create(Venta venta) throws SQLException;
    Venta findById(Letra letra, int numero, int idProducto) throws SQLException;
    List<Venta> findAll() throws SQLException;
    int update(Venta venta) throws SQLException;
    int delete(Letra letra, int numero,int idProducto) throws SQLException;
    


}
