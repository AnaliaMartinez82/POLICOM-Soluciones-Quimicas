package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories;

public class MateriaPrimaDao {

}
