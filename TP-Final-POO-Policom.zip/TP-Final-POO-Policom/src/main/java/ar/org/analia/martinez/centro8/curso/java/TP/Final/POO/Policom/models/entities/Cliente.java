package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.TipoCliente;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cliente {
     /* create table clientes(
         idCliente int auto_increment primary Key,
         nombre varchar(100) not null,
         tipoCliente enum('individual', 'empresa'),
         cuit char(11) not null,
         dni char(8),
         email varchar(50) not null,
         telefono varchar(10) not null,
         direccion varchar(50)
         ); 
     */

     private int idCliente;
     private String nombre;
     private TipoCliente tipoCliente;
     private String cuit;
     private String dni;
     private String email;
     private String telefono;
     private String direccion;
 
}
