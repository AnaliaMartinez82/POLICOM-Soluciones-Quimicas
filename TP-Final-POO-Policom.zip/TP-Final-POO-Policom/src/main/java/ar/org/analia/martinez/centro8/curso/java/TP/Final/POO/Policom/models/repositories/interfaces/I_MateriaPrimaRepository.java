package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.MateriaPrima;


public interface I_MateriaPrimaRepository {

    void create(MateriaPrima materiaPrima) throws SQLException;
    MateriaPrima findById(int idMateriaPrima) throws SQLException;
    List<MateriaPrima> findAll() throws SQLException;
    int update(MateriaPrima materiaPrima) throws SQLException;
    int delete(int idMateriaPrima) throws SQLException;
    List<MateriaPrima> findByNombreMateriaPrima(String nombreMP) throws SQLException;

}
