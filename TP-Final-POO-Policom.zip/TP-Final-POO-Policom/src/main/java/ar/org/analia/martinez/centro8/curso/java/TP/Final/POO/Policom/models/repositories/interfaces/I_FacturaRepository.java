package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Factura;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.Letra;

public interface I_FacturaRepository {

    void create(Factura factura) throws SQLException;
    Factura findByIdLetraNumero(Letra letra, int numero) throws SQLException;
    List<Factura> findAll() throws SQLException;
    int update(Factura factura) throws SQLException;
    int delete(Letra letra, int numero) throws SQLException;
    List<Factura> findByFecha(LocalDate fecha) throws SQLException;

}
