package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductoCosto {
   /* create table productoCostos(
      idProducto int auto_increment primary key,
      nombreProducto varchar(50) not null,
      tiempoDeProduccionEnHoras double not null,
      precioPorHora double not null,
      precioTiempoTotal double not null,
      valorEnvase double not null,
      presentacionCantidad double not null,
      precioCostoTotal double,
      precioVenta double
      );
    */

    private Integer idProducto;
    private String nombreProducto;
    private double tiempoDeProduccionEnHoras;
    private double precioPorHora;
    private double precioTiempoTotal;
    private double valorEnvase;
    private double presentacionCantidad;
    private double precioCostoTotal;
    private double precioVenta;
}
