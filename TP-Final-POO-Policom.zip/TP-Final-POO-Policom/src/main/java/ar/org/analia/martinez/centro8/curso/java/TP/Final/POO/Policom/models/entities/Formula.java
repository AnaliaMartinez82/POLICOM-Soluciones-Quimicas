package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Formula {
     /* create table formulas(
        idMateriaPrima int,
        idProducto int,
        porcentajeDeMateriaPrimaEnElProducto double,
        primary key(idMateriaPrima, IdProducto)
         );
      */

      private Integer idMateriaPrima;
      private Integer idProducto;
      private double porcentajeDeMateriaPrimaEnElProducto;

}
