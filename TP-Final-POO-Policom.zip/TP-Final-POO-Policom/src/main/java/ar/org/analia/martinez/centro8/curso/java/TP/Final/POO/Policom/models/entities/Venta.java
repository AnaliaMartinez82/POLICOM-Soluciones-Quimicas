package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.Letra;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Venta {
    /* create table ventas(
       letra enum('A','B','C','E'),
       numero int,
       idProducto int,
       cantidad int not null,
       subtotal double unsigned,
       primary key(letra, numero, idProducto)
       );
     */

     private Letra letra;
     private Integer numero;
     private Integer idProducto;
     private Integer cantidad;
     private double subtotal;

}
