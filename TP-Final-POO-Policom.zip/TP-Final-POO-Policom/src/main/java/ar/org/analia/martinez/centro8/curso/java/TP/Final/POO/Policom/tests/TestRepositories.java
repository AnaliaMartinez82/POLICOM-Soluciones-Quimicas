package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.tests;

public class TestRepositories {

}
