package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Cliente;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Factura;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Formula;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.MateriaPrima;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.ProductoCosto;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Venta;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.TipoCliente;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.Letra;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.UnidadMedicion;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.ClienteRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.FacturaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.FormulaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.MateriaPrimaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.ProductoCostoRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.VentaRepository;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_ClienteRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_FacturaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_FormulaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_MateriaPrimaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_ProductoCostoRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_VentaRepository;

import java.time.LocalDate;
import java.util.List;

@SpringBootApplication(scanBasePackages = "ar.org.centro8.curso.java")
public class TestRepositories {

     public static void main(String[] args) {
     
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
            I_ClienteRepository clienteRepository = context.getBean(ClienteRepository.class);
            I_FacturaRepository facturaRepository = context.getBean(FacturaRepository.class);
            I_FormulaRepository formulaRepository = context.getBean(FormulaRepository.class);
            I_MateriaPrimaRepository materiaPrimaRepository = context.getBean(MateriaPrimaRepository.class);
            I_ProductoCostoRepository productoCostoRepository = context.getBean(ProductoCostoRepository.class);
            I_VentaRepository ventaRepository = context.getBean(VentaRepository.class);

            //Pruebas para clientes

            //TEST 1: Crear un nuevo cliente
            System.out.println("\n>>> Test 1: creando un nuevo cliente...");
            Cliente nuevoCliente = new Cliente(0, "Ricardo Iorio",TipoCliente.INDIVIDUAL,"23456789163", "19876543", "true@gmail.com","1122334455","callesita de Buenos Aires 123"); 
            clienteRepository.create(nuevoCliente); //el id se asigna dentro del método create
            if(nuevoCliente.getIdCliente()>0){
                System.out.println(" ## Cliente creado con el ID:" + nuevoCliente.getIdCliente());
                System.out.println(nuevoCliente);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el cliente !!");
            }

            //TEST 2: Buscar un Cliente por ID (existente)
            System.out.println("\n>>> Test 2: Buscando cliente por ID " + nuevoCliente.getIdCliente() + "...");
            Cliente clienteEncontrado = clienteRepository.findById(nuevoCliente.getIdCliente());
            if(clienteEncontrado!=null){
                System.out.println(" ## Cliente encontrado: " + clienteEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el cliente con el ID " + nuevoCliente.getIdCliente());
            }

            //TEST 3: Buscar un Cliente por ID (inexistente)
            System.out.println("\n>>> Test 3: Buscando Cliente con ID 999 (inexistente)");
            Cliente clienteNoEncontrado = clienteRepository.findById(999);
            if(clienteNoEncontrado != null){
                System.out.println(" ## Cliente encontrado: " + clienteNoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró alumno con ID 999 !!");
            }

            //Test 4: Actualizar un Cliente
            System.out.println("\n>>> Test 4: Actualizando Cliente " + nuevoCliente.getIdCliente() + "...");
            nuevoCliente.setNombre("Ricardo Horacio"); //cambia el nombre del cliente recién creado
            int filasAfectadas = clienteRepository.update(nuevoCliente);
            if(filasAfectadas==1){
                System.out.println(" ## Cliente " + nuevoCliente.getIdCliente() + "actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + clienteRepository.findById(nuevoCliente.getIdCliente()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar al cliente !!");
            }

            //Test 5: Listar todos los clientes
            System.out.println("\n>>> Test 5: Listando todos los clientes...");
            List<Cliente> clientesTodos = clienteRepository.findAll();
            if(!clientesTodos.isEmpty()){
                System.out.println(" ## Clientes encontrados: " + clientesTodos.size());
                clientesTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron registros de clientes");
            }

            //Test 6: Eliminar un cliente
            System.out.println("\n>>> Test 6: Eliminando Cliente " + nuevoCliente.getIdCliente() + "...");
            int filasAfectadasDelete = clienteRepository.delete(nuevoCliente.getIdCliente());
            if(filasAfectadasDelete==1){
                System.out.println(" ## Cliente " + nuevoCliente.getIdCliente() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + clienteRepository.findById(nuevoCliente.getIdCliente()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar al cliente !!");
            }

             //Pruebas para facturas
            
            //Test 7: Crear una nueva factura
            System.out.println("\n>>> Test 7: creando una nueva Factura...");
            Factura nuevaFactura = new Factura(Letra.A, 2, LocalDate.of(2024, 4, 15), 11800.50, 4);
            facturaRepository.create(nuevaFactura);
            if(nuevaFactura.getNumero()>0 && nuevaFactura.getLetra()!=null){
                System.out.println(" ## Factura creada correctamente con letra " + nuevaFactura.getLetra() +"numero: "+ nuevaFactura.getNumero());
                System.out.println(nuevaFactura);
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo crear la factura !!");
            }

            //Test 8: Buscar una factura por ID 
            System.out.println("\n>>> Test 8: buscando factura por Letra y numero " + nuevaFactura.getLetra() +"  "+ nuevaFactura.getNumero()+ " ...");
            Factura facturaEncontrada = facturaRepository.findByIdLetraNumero(nuevaFactura.getLetra(),nuevaFactura.getNumero());
            if(facturaEncontrada!=null){
                System.out.println(" ## factura encontrada: " + facturaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró la factura con letra y numero " + nuevaFactura.getLetra() +"  "+ nuevaFactura.getNumero());
            }

            //Test 9: Listar todos las facturas
            System.out.println("\n>>> Test 9: listar todas los facturas");
            List<Factura> facturasTodas = facturaRepository.findAll();
            if(!facturasTodas.isEmpty()){
                System.out.println(" ## Facturas encontradas: " + facturasTodas.size());
                facturasTodas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron registros de facturas !!");
            }

            //Test 10: Buscar facturas por fecha
            System.out.println("\n>>> Test 10: buscando facturas por fecha");
            List<Factura> facturasPorFecha = facturaRepository.findByFecha(LocalDate.of(2024,04,15));
            if(!facturasPorFecha.isEmpty()){
                System.out.println(" ## Facturas encontradas: " + facturasPorFecha.size());
                facturasPorFecha.forEach(System.out::println);
            } else{
                System.out.println(" ¡¡ No se encontraron facturas para esa fecha");
                //no necesariamente es un error que no haya cursos
            }

            //Test 11: Actualizar una factura
            System.out.println("\n>>> Test 11: Actualizando factura " + nuevaFactura.getLetra() + nuevaFactura.getNumero() + " ...");
            nuevaFactura.setPrecioFinal(11700.00);
            nuevaFactura.setIdCliente(2);
            int filasAfectadasFactura = facturaRepository.update(nuevaFactura);
            if(filasAfectadasFactura==1){
                System.out.println(" ## Factura " + nuevaFactura.getLetra() +nuevaFactura.getIdCliente()+ " actualizado correctamente.");
                System.out.println("Verificando actualización: " + facturaRepository.findByIdLetraNumero(nuevaFactura.getLetra(), nuevaFactura.getNumero()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo actualizar la factura !!");
            }

            //Test 12: Eliminar una factura
            System.out.println("\n>>> Test 12: eliminando la factura  " + nuevaFactura.getLetra() + nuevaFactura.getNumero());
            int filasAfectadasFacturasDelete = facturaRepository.delete(nuevaFactura.getLetra(),nuevaFactura.getNumero());
            if(filasAfectadasFacturasDelete == 1){
                System.out.println(" ## Factura " + nuevaFactura.getLetra()+ " numero: "+ nuevaFactura.getNumero() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + facturaRepository.findByIdLetraNumero(nuevaFactura.getLetra(),nuevaFactura.getNumero()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar la factura !!");
            }
             
                //Pruebas para Producto Costos

             // TEST 13: Crear un nuevo Producto
            System.out.println("\n>>> Test 1: creando un nuevo producto...");
            ProductoCosto nuevoProductoCosto = new ProductoCosto(0,"Destapa T el caño", 12.00,6000,72000,500,1,1200,12000); 
            productoCostoRepository.create(nuevoProductoCosto); //el id se asigna dentro del método create
            if(nuevoProductoCosto.getIdProducto()>0){
                System.out.println(" ## Producto creado con el ID:" + nuevoProductoCosto.getIdProducto());
                System.out.println(nuevoProductoCosto);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el registro de producto !!");
            }  

            //TEST 14: Buscar un Producto por ID (existente)
            System.out.println("\n>>> Test 2: Buscando productoCosto por ID " + nuevoProductoCosto.getIdProducto() + "...");
            ProductoCosto productoCostoEncontrado = productoCostoRepository.findById(nuevoProductoCosto.getIdProducto());
            if(productoCostoEncontrado!=null){
                System.out.println(" ## Producto encontrado: " + productoCostoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el producto con el ID " + nuevoProductoCosto.getIdProducto());
            }

            //TEST 15: Buscar un Producto por ID (inexistente)
            System.out.println("\n>>> Test 3: Buscando Producto con ID 999 (inexistente)");
            ProductoCosto productoCostoNoEncontrado = productoCostoRepository.findById(999);
            if(productoCostoNoEncontrado != null){
                System.out.println(" ## Producto encontrado: " + productoCostoNoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró producto con ID 999 !!");
            }

            //Test 16: Actualizar un Producto
            System.out.println("\n>>> Test 4: Actualizando Producto " + nuevoProductoCosto.getIdProducto() + "...");
            nuevoProductoCosto.setNombreProducto("Destapa T caño"); //cambia el nombre del producto recién creado
            int filasAfectadas2 = productoCostoRepository.update(nuevoProductoCosto);
            if(filasAfectadas2==1){
                System.out.println(" ## Producto " + nuevoProductoCosto.getIdProducto() + "actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + productoCostoRepository.findById(nuevoProductoCosto.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar al producto !!");
            }

            //Test 16: Listar todos los productos
            System.out.println("\n>>> Test 5: Listando todos los productos...");
            List<ProductoCosto> productoCostoTodos = productoCostoRepository.findAll();
            if(!productoCostoTodos.isEmpty()){
                System.out.println(" ## Productos encontrados: " + productoCostoTodos.size());
                productoCostoTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron productos");
            }

            //Test 17: Eliminar un producto
            System.out.println("\n>>> Test 6: Eliminando Producto " + nuevoProductoCosto.getIdProducto() + "...");
            int filasAfectadasDelete3 = productoCostoRepository.delete(nuevoProductoCosto.getIdProducto());
            if(filasAfectadasDelete3==1){
                System.out.println(" ## Producto " + nuevoProductoCosto.getIdProducto() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + productoCostoRepository.findById(nuevoProductoCosto.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar al producto !!");
            }

                //Pruebas para materias Primas
        
             //TEST 18: Crear una nueva materia prima
             System.out.println("\n>>> Test 1: creando un nuevo registro de materia prima...");
             MateriaPrima nuevaMateriaPrima = new MateriaPrima(0,"Bicarbonato",UnidadMedicion.KILO,2500.0,50); 
             materiaPrimaRepository.create(nuevaMateriaPrima); //el id se asigna dentro del método create
             if(nuevaMateriaPrima.getIdMateriaPrima()>0){
                System.out.println(" ## Materia Prima creada con el ID:" + nuevaMateriaPrima.getIdMateriaPrima());
                System.out.println(nuevaMateriaPrima);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el registro de materia prima en el sistema !!");
            }

            //TEST 19: Buscar una Materia Prima por ID (existente)
            System.out.println("\n>>> Test 2: Buscando materia prima por ID " + nuevaMateriaPrima.getIdMateriaPrima() + "...");
            MateriaPrima materiaPrimaEncontrada = materiaPrimaRepository.findById(nuevaMateriaPrima.getIdMateriaPrima());
            if(materiaPrimaEncontrada!=null){
                System.out.println(" ## Materia Prima encontrada: " + materiaPrimaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el registro de materia prima con el ID " + nuevaMateriaPrima.getIdMateriaPrima());
            }

            //TEST 20: Buscar un Materia Prima por ID (inexistente)
            System.out.println("\n>>> Test 3: Buscando Materia Prima con ID 999 (inexistente)");
            MateriaPrima materiaPrimaNoEncontrada = materiaPrimaRepository.findById(999);
            if(materiaPrimaNoEncontrada != null){
                System.out.println(" ## Materia Prima encontrada: " + materiaPrimaNoEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró registro de Materia Prima con ID 999 !!");
            }

            //Test 21: Actualizar una Materia Prima
            System.out.println("\n>>> Test 4: Actualizando Materia Prima " + nuevaMateriaPrima.getIdMateriaPrima() + "...");
            nuevaMateriaPrima.setNombreMP("Bicarbonato de Sodio"); //cambia el nombre de la materia prima recién creada
            int filasAfectadas4 = materiaPrimaRepository.update(nuevaMateriaPrima);
            if(filasAfectadas4==1){
                System.out.println(" ## Materia Prima " + nuevaMateriaPrima.getIdMateriaPrima() + "actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + materiaPrimaRepository.findById(nuevaMateriaPrima.getIdMateriaPrima()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar el registro de Materia Prima !!");
            }

            //Test 22: Listar todos las Materia Primas
            System.out.println("\n>>> Test 5: Listando todos las Materias Primas...");
            List<MateriaPrima> materiaPrimasTodas = materiaPrimaRepository.findAll();
            if(!materiaPrimasTodas.isEmpty()){
                System.out.println(" ## Materias Primas encontradas: " + materiaPrimasTodas.size());
                materiaPrimasTodas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron materias primas");
            }

            //Test 23: Eliminar una Materia Prima
            System.out.println("\n>>> Test 6: Eliminando Materia Prima " + nuevaMateriaPrima.getIdMateriaPrima() + "...");
            int filasAfectadasDelete4 = materiaPrimaRepository.delete(nuevaMateriaPrima.getIdMateriaPrima());
            if(filasAfectadasDelete4==1){
                System.out.println(" ## Materia Prima " + nuevaMateriaPrima.getIdMateriaPrima() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + materiaPrimaRepository.findById(nuevaMateriaPrima.getIdMateriaPrima()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el registro de la Materia Prima !!");
            }

                  //Pruebas para Formulas

            //TEST 24: Crear un nuevo registro de formula
            System.out.println("\n>>> Test 1: creando un nueva formula...");
            Formula nuevaFormula = new Formula(33,33,75.0);
            formulaRepository.create(nuevaFormula); 
            if(nuevaFormula.getIdMateriaPrima()>0 && nuevaFormula.getIdProducto()>0){
                System.out.println(" ## Formula creada con el ID:" + nuevaFormula.getIdMateriaPrima()+nuevaFormula.getIdProducto());
                System.out.println(nuevaFormula);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el registro de formula en el sistema !!");
            }

            //TEST 25: Buscar una Formula por ID (existente)
            System.out.println("\n>>> Test 2: Buscando formula por ID " + nuevaFormula.getIdMateriaPrima() +"  "+ nuevaFormula.getIdProducto() + "...");
            Formula formulaEncontrada = formulaRepository.findById(nuevaFormula.getIdMateriaPrima(),nuevaFormula.getIdProducto());
            if(formulaEncontrada!=null){
                System.out.println(" ## Formula encontrada: " + formulaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el registro de formula con el ID " + nuevaFormula.getIdMateriaPrima()+" "+ nuevaFormula.getIdProducto());
            }

            //TEST 26: Buscar una Formula por ID (inexistente)
            System.out.println("\n>>> Test 3: Buscando Formula con IDMateriaPrima 999 IDProducto 999 (inexistente)");
            Formula formulaNoEncontrada = formulaRepository.findById(999,999);
            if(formulaNoEncontrada != null){
                System.out.println(" ## Formula encontrada: " + formulaNoEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el registro de formula con IDMateriaPrima 999 y IDProducto 999 !!");
            }

            //Test 27: Actualizar un Formula
            System.out.println("\n>>> Test 4: Actualizando Formula " + nuevaFormula.getIdMateriaPrima() +" "+ nuevaFormula.getIdProducto()+ "...");
            nuevaFormula.setPorcentajeDeMateriaPrimaEnElProducto(0.9); //cambia el registro de la formula recién creada
            int filasAfectadas5 = formulaRepository.update(nuevaFormula);
            if(filasAfectadas5==1){
                System.out.println(" ## Formula " + nuevaFormula.getIdMateriaPrima() +"  " + nuevaFormula.getIdProducto()+"actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + formulaRepository.findById(nuevaFormula.getIdMateriaPrima(), nuevaFormula.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar el registro de formula !!");
            }

            //Test 28: Listar todos los registros de formulas
            System.out.println("\n>>> Test 5: Listando todos los registros de formulas...");
            List<Formula> formulasTodas = formulaRepository.findAll();
            if(!formulasTodas.isEmpty()){
                System.out.println(" ## Formulas encontrados: " + formulasTodas.size());
                formulasTodas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron registrs de formulas");
            }

            //Test 29: Eliminar un registro de formula
            System.out.println("\n>>> Test 6: Eliminando registro de formula " + nuevaFormula.getIdMateriaPrima() +"  "+ nuevaFormula.getIdProducto() + "...");
            int filasAfectadasDelete5 = formulaRepository.delete(nuevaFormula.getIdMateriaPrima(),nuevaFormula.getIdProducto());
            if(filasAfectadasDelete5==1){
                System.out.println(" ## formula " + nuevaFormula.getIdMateriaPrima() +" "+ nuevaFormula.getIdProducto() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + formulaRepository.findById(nuevaFormula.getIdMateriaPrima(),nuevaFormula.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el registro de formula !!");
            }

                //Pruebas para Ventas

             //TEST 30: Crear un nuevo registro de venta
            System.out.println("\n>>> Test 1: creando un nuevo registro de venta...");
            Venta nuevaVenta = new Venta(Letra.B, 27, 27, 2,5000); //el idCurso 1 es Matemática
            ventaRepository.create(nuevaVenta); 
            if(nuevaVenta.getNumero()>0 && nuevaVenta.getLetra()!=null && nuevaVenta.getIdProducto()>0){
                System.out.println(" ## Venta creada con el ID:" + nuevaVenta.getLetra() +", "+ nuevaVenta.getNumero() +", "+ nuevaVenta.getIdProducto());
                System.out.println(nuevaVenta);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el registro de venta !!");
            }

            //TEST 31: Buscar Venta por ID (existente)
            System.out.println("\n>>> Test 2: Buscando registro de venta por ID " + nuevaVenta.getLetra() +", "+ nuevaVenta.getNumero() +", "+ nuevaVenta.getIdProducto() + "...");
            Venta ventaEncontrada = ventaRepository.findById(nuevaVenta.getLetra(), nuevaVenta.getNumero(), nuevaVenta.getIdProducto());
            if(ventaEncontrada!=null){
                System.out.println(" ## Venta encontrada: " + ventaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el registro de Venta con el ID " + nuevaVenta.getLetra() +", "+ nuevaVenta.getNumero() +", "+ nuevaVenta.getIdProducto() );
            }

            //TEST 32: Buscar un Venta por ID (inexistente)
            System.out.println("\n>>> Test 3: Buscando venta con  ID: Letra C, idNumero:999, idNumero:999 (inexistente)");
            Venta ventaNoEncontrada = ventaRepository.findById(Letra.C,999,999);
            if(ventaNoEncontrada != null){
                System.out.println(" ## Venta encontrada: " + ventaNoEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró alumno con ID: Letra C, idNumero:999, idNumero:999 !!");
            }

            //Test 33: Actualizar un registro de venta
            System.out.println("\n>>> Test 4: Actualizando registro de venta " + nuevaVenta.getLetra() +", "+ nuevaVenta.getNumero() +", " + nuevaVenta.getIdProducto() + "...");
            nuevaVenta.setSubtotal(6800.0); //cambia el subtotal recién creado
            int filasAfectadas6 = ventaRepository.update(nuevaVenta);
            if(filasAfectadas6==1){
                System.out.println(" ## Venta " + nuevaVenta.getLetra() +", "+ nuevaVenta.getNumero() +", "+ nuevaVenta.getIdProducto() + "actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + ventaRepository.findById(nuevaVenta.getLetra(), nuevaVenta.getNumero(), nuevaVenta.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar el registro de Venta !!");
            }

            //Test 34: Listar todos los regisros de Ventas
            System.out.println("\n>>> Test 5: Listando todos los regisros de Ventas...");
            List<Venta> ventasTodas = ventaRepository.findAll();
            if(!ventasTodas.isEmpty()){
                System.out.println(" ## Ventas encontradas: " + ventasTodas.size());
                ventasTodas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron Ventas");
            }

            //Test 6: Eliminar un registro de Venta
            System.out.println("\n>>> Test 6: Eliminando registro de Venta " + nuevaVenta.getLetra() +", "+ nuevaVenta.getNumero() +", "+ nuevaVenta.getIdProducto() + "...");
            int filasAfectadasDelete6 = ventaRepository.delete(nuevaVenta.getLetra(), nuevaVenta.getNumero(), nuevaVenta.getIdProducto());
            if(filasAfectadasDelete6==1){
                System.out.println(" ## Alumno " + nuevaVenta.getLetra() +", "+ nuevaVenta.getNumero() +", "+ nuevaVenta.getIdProducto() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + ventaRepository.findById(nuevaVenta.getLetra(), nuevaVenta.getNumero(), nuevaVenta.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el registro Venta !!");
            }
            
        }  catch (Exception e) {
            System.out.println(" ¡¡ ERROR de la Base de Datos durante las pruebas !!");
            e.printStackTrace();
        } finally{
            System.out.println("\n <<< FINALIZANDO PRUEBAS >>>");
            System.out.println("<<< CONTEXTO DE SPRING CERRADO >>>");
        }
   }
}
