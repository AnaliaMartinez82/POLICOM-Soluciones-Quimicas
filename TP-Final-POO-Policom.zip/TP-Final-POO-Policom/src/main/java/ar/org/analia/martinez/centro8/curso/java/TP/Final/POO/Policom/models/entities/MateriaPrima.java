package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.UnidadMedicion;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MateriaPrima {
    /* create table materiasPrimas(
       idMateriaPrima int auto_increment primary key,
       nombreMP varchar(50) not null,
       unidadMedicion enum('litro','kilo') not null,
       precioCosto double unsigned not null,
       stock int
       );
     */

     private Integer idMateriaPrima;
     private String nombreMP;
     private UnidadMedicion unidadMedicion;
     private double precioCosto;
     private Integer stock;
}
