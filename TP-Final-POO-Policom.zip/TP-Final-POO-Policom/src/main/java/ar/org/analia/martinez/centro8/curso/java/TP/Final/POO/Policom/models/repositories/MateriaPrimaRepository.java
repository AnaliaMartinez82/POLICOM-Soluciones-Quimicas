package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.MateriaPrima;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.UnidadMedicion;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_MateriaPrimaRepository;

@Repository
public class MateriaPrimaRepository implements I_MateriaPrimaRepository {

    /* private Integer idMateriaPrima;
     private String nombreMP;
     private UnidadMedicion unidadMedicion;
     private double precioCosto;
     private Integer stock; */
    
    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO materiasPrimas (nombreMP, unidadMedicion, precioCosto, stock) VALUES (?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM materiasPrimas WHERE idMateriaPrima=?";
    private static final String SQL_FIND_ALL =
        "SELECT * materiasPrimas";
    private static final String SQL_UPDATE =
        "UPDATE materiasPrimas SET nombreMP=?, unidadMedicion=?, precioCosto=?, stock=?, WHERE idMateriaPrima=?";
    private static final String SQL_DELETE =
        "DELETE FROM materiasPrimas WHERE idMateriaPrima=?";
    private static final String SQL_FIND_BY_NOMBRE_MATERIA_PRIMA =
        "SELECT * FROM materiasPrimas WHERE nombreMP=?";

    public MateriaPrimaRepository(DataSource dataSource){
        this.dataSource=dataSource;
    }

    @Override
    public void create(MateriaPrima materiaPrima) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, materiaPrima.getNombreMP());
            ps.setString(2, materiaPrima.getUnidadMedicion().name());
            ps.setDouble(3, materiaPrima.getPrecioCosto());
            ps.setInt(4, materiaPrima.getStock());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if(keys.next()){
                    materiaPrima.setIdMateriaPrima(keys.getInt(1));
                }
            } 
        }
    }

    @Override
    public MateriaPrima findById(int idMateriaPrima) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idMateriaPrima);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            } 
        } 
        return null;
    }

    @Override
    public List<MateriaPrima> findAll() throws SQLException {
        List<MateriaPrima> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while(rs.next()){
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(MateriaPrima materiaPrima) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, materiaPrima.getNombreMP());
            ps.setString(2, materiaPrima.getUnidadMedicion().name());
            ps.setDouble(3, materiaPrima.getPrecioCosto());
            ps.setInt(4, materiaPrima.getStock());
            ps.setInt(6, materiaPrima.getIdMateriaPrima());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public int delete(int idMateriaPrima) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idMateriaPrima);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<MateriaPrima> findByNombreMateriaPrima(String nombreMP) throws SQLException {
        List<MateriaPrima> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NOMBRE_MATERIA_PRIMA)) {
            ps.setString(1,nombreMP);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
    }

    private MateriaPrima mapRow(ResultSet rs) throws SQLException{
        MateriaPrima mp = new MateriaPrima();
        mp.setIdMateriaPrima(rs.getInt("idMateriaPrima"));
        mp.setNombreMP(rs.getString("nombreMP"));
        mp.setUnidadMedicion(UnidadMedicion.valueOf(rs.getString("unidad medicion")));
        mp.setPrecioCosto(rs.getDouble("precio costo"));
        mp.setStock(rs.getInt("stock"));
        return mp; 
    }
 
}
