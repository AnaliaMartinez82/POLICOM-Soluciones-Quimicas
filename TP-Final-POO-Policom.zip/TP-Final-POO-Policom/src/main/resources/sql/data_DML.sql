-- CLIENTES
INSERT INTO clientes (nombre, tipoCliente, cuit, dni, email, telefono, direccion) VALUES
('Juan Pérez', 'individual', '20345678901', '34567890', 'juanperez@gmail.com', '1134567890', 'Av. Siempre Viva 123'),
('Ferretería El Tornillo', 'empresa', '30709876543', NULL, 'contacto@tornillo.com.ar', '1123456789', 'Av. Rivadavia 9999'),
('Ana Gómez', 'individual', '27234567890', '23456789', 'ana.gomez@mail.com', '1167891234', 'Calle Falsa 456'),
('Carlos López', 'individual', '20333222333', '33112233', 'carlos.lopez@mail.com', '1144455566', 'Calle Luna 123'),
('Distribuidora Max', 'empresa', '30999999888', NULL, 'ventas@max.com.ar', '1177766655', 'Av. San Martín 452'),
('Marta Rodríguez', 'individual', '27888887777', '88997766', 'marta.r@gmail.com', '1166611122', 'Calle Sol 999'),
('Supermercado Don José', 'empresa', '30666665555', NULL, 'admin@donjose.com', '1122233344', 'Av. Mitre 1450'),
('Lucía Fernández', 'individual', '20987654321', '98765432', 'lucia.fdz@hotmail.com', '1199998888', 'Pasaje Verde 234');

-- MATERIAS PRIMAS
INSERT INTO materiasPrimas (nombreMP, unidadMedicion, precioCosto, stock) VALUES
('Alcohol Etílico', 'litro', 200.00, 500),
('Glicerina', 'litro', 150.00, 300),
('Esencia Lavanda', 'litro', 400.00, 100),
('Colorante Azul', 'kilo', 250.00, 50),
('Aceite de Coco', 'litro', 180.00, 250),
('Colorante Rojo', 'kilo', 270.00, 70),
('Fragancia Vainilla', 'litro', 350.00, 90),
('Bicarbonato de Sodio', 'kilo', 100.00, 500),
('Agua Destilada', 'litro', 50.00, 1000);

-- PRODUCTOS
INSERT INTO productoCostos (nombreProducto, tiempoDeProduccionEnHoras, precioPorHora, precioTiempoTotal, valorEnvase, presentacionCantidad, precioCostoTotal, precioVenta) VALUES
('Alcohol en Gel 500ml', 1.0, 500.00, 500.00, 100.00, 0.5, NULL, 1200.00),
('Jabón Líquido 1L', 0.5, 400.00, 200.00, 80.00, 1.0, NULL, 900.00),
('Jabón de Coco 250g', 0.6, 400, 240, 60, 0.25, NULL, NULL),
('Desinfectante Lavanda 2L', 1.2, 500, 600, 120, 2.0, NULL, NULL),
('Spray Antiséptico 100ml', 0.4, 550, 220, 40, 0.1, NULL, NULL),
('Shampoo Natural 1L', 1.0, 600, 600, 150, 1.0, NULL, NULL),
('Limpiador Multiuso 500ml', 0.8, 480, 384, 90, 0.5, NULL, NULL);

-- FORMULAS
INSERT INTO formulas (idMateriaPrima, idProducto, porcentajeDeMateriaPrimaEnElProducto) VALUES
(1, 1, 0.7), -- Alcohol Etílico en Alcohol en Gel
(2, 1, 0.2), -- Glicerina en Alcohol en Gel
(3, 1, 0.1), -- Esencia Lavanda en Alcohol en Gel
(2, 2, 0.6), -- Glicerina en Jabón
(4, 2, 0.05), -- Colorante Azul en Jabón
(3, 2, 0.1), -- Esencia en Jabón
(5, 3, 0.7), -- Agua Destilada en Jabón de Coco
(1, 3, 0.2), -- Aceite de Coco en Jabón
(7, 3, 0.1), -- Fragancia Vainilla en Jabón
(5, 4, 0.6), -- Agua Destilada en Desinfectante
(3, 4, 0.4), -- Esencia Lavanda en Desinfectante
(6, 5, 0.05), -- Colorante Rojo en Spray
(1, 5, 0.6), -- Aceite de Coco en Spray
(8, 6, 0.5), -- Bicarbonato de Sodio en Shampoo
(1, 6, 0.3), -- Aceite de Coco en Shampoo
(5, 7, 0.8); -- Agua Destilada en Limpiador

-- FACTURAS
INSERT INTO facturas (letra, numero, fecha, precioFinal, idCliente) VALUES
('A', 1001, '2025-07-01', 2400.00, 1),
('B', 2001, '2025-07-02', 1800.00, 2),
('A', 1002, '2025-07-03', 5000.00, 4),
('B', 2002, '2025-07-04', 6000.00, 5),
('C', 3001, '2025-07-05', 7000.00, 2),
('A', 1003, '2025-07-06', 8000.00, 1),
('E', 4001, '2025-07-06', 9000.00, 3);

-- VENTAS
INSERT INTO ventas (letra, numero, idProducto, cantidad, subtotal) VALUES
('A', 1001, 1, 2, 2400.00),
('B', 2001, 2, 2, 1800.00),
('A', 1002, 3, 5, 5000.00),
('B', 2002, 4, 3, 6000.00),
('C', 3001, 5, 2, 7000.00),
('A', 1003, 6, 4, 8000.00),
('E', 4001, 7, 6, 9000.00);
