-- drop database if exists policom;
-- create database if not exists policom;
-- use policom;
-- drop table if exists clientes, facturas, productoCostos, materiasPrimas,
-- ventas,formulas;

create table clientes(
idCliente int auto_increment primary Key,
nombre varchar(100) not null,
tipoCliente enum('individual', 'empresa'),
cuit char(11) not null,
dni char(8),
email varchar(50) not null,
telefono varchar(10) not null,
direccion varchar(50)
);

create table facturas(
letra enum('A','B','C','E'),
numero int,
fecha date not null,
precioFinal double not null,
idCliente int not null,
primary key(letra, numero)
);

create table productoCostos(
idProducto int auto_increment primary key,
nombreProducto varchar(50) not null,
tiempoDeProduccionEnHoras double not null,
precioPorHora double not null,
precioTiempoTotal double not null,
valorEnvase double not null,
presentacionCantidad double not null,
precioCostoTotal double,
precioVenta double
);

create table materiasPrimas(
idMateriaPrima int auto_increment primary key,
nombreMP varchar(50) not null,
unidadMedicion enum('litro','kilo') not null,
precioCosto double unsigned not null,
stock int
);

create table ventas(
letra enum('A','B','C','E'),
numero int,
idProducto int,
cantidad int not null,
subtotal double unsigned,
primary key(letra, numero, idProducto)
);

create table formulas(
idMateriaPrima int,
idProducto int,
porcentajeDeMateriaPrimaEnElProducto double,
primary key(idMateriaPrima, idProducto)
);

alter table facturas
add constraint fk_facturas_clientes
foreign key (idCliente)
references clientes(idCliente);

alter table ventas
add constraint fk_ventas_facturas
foreign key (letra, numero)
references facturas(letra, numero);

alter table ventas
add constraint fk_ventas_productoCostos
foreign key (idProducto)
references productoCostos(idProducto);

alter table formulas
add constraint fk_formulas_productoCostos
foreign key (idProducto)
references productoCostos(idProducto);

alter table formulas
add constraint fk_formulas_materiasPrimas
foreign key (idMateriaPrima)
references materiasPrimas(idMateriaPrima);
