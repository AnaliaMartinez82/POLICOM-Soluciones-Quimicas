-- -------------------------------QUERIES--------------------------
-- 1-¿CUAL ES EL PRODUCTO MAS BARATO?
SELECT nombreProducto, precioVenta
FROM productoCostos
WHERE precioVenta = (SELECT MIN(precioVenta) FROM productoCostos);

-- 2-¿Cual es es producto que demora mas en producirse?
SELECT nombreProducto, tiempoDeProduccionEnHoras
FROM productoCostos
WHERE tiempoDeProduccionEnHoras = (
  SELECT MAX(tiempoDeProduccionEnHoras)
  FROM productoCostos
);

-- 3-¿Cual es la materia prima que tiene mayor porcetaje en un producto?
SELECT m.nombreMP, p.nombreProducto, fo.porcentajeDeMateriaPrimaEnElProducto
FROM materiasPrimas m
JOIN formulas fo ON m.idMateriaPrima = fo.idMateriaPrima
JOIN productoCostos p ON fo.idProducto = p.idProducto
WHERE fo.porcentajeDeMateriaPrimaEnElProducto = (
  SELECT MAX(porcentajeDeMateriaPrimaEnElProducto)
  FROM formulas
);

-- 4-¿cual fue el producto mas vendido en una misma factura en el año 2025?
SELECT p.nombreProducto, v.cantidad, fa.letra, fa.numero, fa.fecha
FROM ventas v
JOIN productoCostos p ON v.idProducto = p.idProducto
JOIN facturas fa ON v.letra = fa.letra AND v.numero = fa.numero
WHERE YEAR(fa.fecha) = 2025
  AND v.cantidad = (
    SELECT MAX(v.cantidad)
    FROM ventas v
    JOIN facturas f ON v.letra = f.letra AND v.numero = f.numero
    WHERE YEAR(f.fecha) = 2025
  );

-- 5-¿quien es el cliente que tiene mayor monto en una factura y que productos compro?
SELECT c.nombre, c.tipoCliente, fa.precioFinal, p.nombreProducto
FROM clientes c
JOIN facturas fa ON c.idCliente = fa.idCliente
JOIN ventas v ON fa.letra = v.letra AND fa.numero = v.numero
JOIN productoCostos p ON v.idProducto = p.idProducto
WHERE (fa.letra, fa.numero) = (
  SELECT letra, numero
  FROM facturas
  ORDER BY precioFinal DESC
  LIMIT 1
);

-- 6-Listar los articulos que aun no fueron vendidos
SELECT p.nombreProducto
FROM productoCostos p 
LEFT JOIN ventas v ON p.idProducto = v.idProducto
WHERE v.idProducto IS NULL;

-- 7-Informar cuantas unidades se vendieron de cada articulo producido
SELECT p.nombreProducto, sum(v.cantidad)"cantidad vendida"
FROM productoCostos p 
JOIN ventas v ON p.idProducto = v.idProducto
group by p.idProducto,p.nombreProducto;

-- 8-Mostrar el porcentaje máximo por cada materia prima y producto:
SELECT m.nombreMP, p.nombreProducto, MAX(fo.porcentajeDeMateriaPrimaEnElProducto)maxPorcentaje
FROM materiasPrimas m
JOIN formulas fo ON m.idMateriaPrima = fo.idMateriaPrima
JOIN productoCostos p ON fo.idProducto = p.idProducto
GROUP BY m.nombreMP, p.nombreProducto;
