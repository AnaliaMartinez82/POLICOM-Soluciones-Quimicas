package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpFinalPooPolicomApplicationTests {

	@Test
	void contextLoads() {
	}

}
