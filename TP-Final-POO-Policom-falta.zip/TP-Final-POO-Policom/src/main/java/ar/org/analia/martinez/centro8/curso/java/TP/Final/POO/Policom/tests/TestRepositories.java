package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Cliente;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Factura;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Formula;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.MateriaPrima;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.ProductoCosto;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Venta;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.TipoCliente;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.Letra;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.UnidadMedicion;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.ClienteRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.FacturaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.FormulaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.MateriaPrimaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.ProductoCostoRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.VentaRepository;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_ClienteRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_FacturaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_FormulaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_MateriaPrimaRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_ProductoCostoRepository;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_VentaRepository;

import java.util.List;

@SpringBootApplication(scanBasePackages = "ar.org.centro8.curso.java")
public class TestRepositories {

     public static void main(String[] args) {
     
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
            I_ClienteRepository clienteRepository = context.getBean(ClienteRepository.class);
            I_FacturaRepository facturaRepository = context.getBean(FacturaRepository.class);
            I_FormulaRepository formulaRepository = context.getBean(FormulaRepository.class);
            I_MateriaPrimaRepository materiaPrimaRepository = context.getBean(MateriaPrimaRepository.class);
            I_ProductoCostoRepository productoCostoRepository = context.getBean(ProductoCostoRepository.class);
            I_VentaRepository ventaRepository = context.getBean(VentaRepository.class);

            //Pruebas para clientes

            //TEST 1: Crear un nuevo cliente
            System.out.println("\n>>> Test 1: creando un nuevo cliente...");
            Cliente nuevoCliente = new Cliente(0, "Ricardo Iorio",TipoCliente.INDIVIDUAL,"23456789163", "19876543", "true@gmail.com","1122334455","callesita de Buenos Aires 123"); 
            clienteRepository.create(nuevoCliente); //el id se asigna dentro del método create
            if(nuevoCliente.getIdCliente()>0){
                System.out.println(" ## Cliente creado con el ID:" + nuevoCliente.getIdCliente());
                System.out.println(nuevoCliente);
            } else{
                System.err.println(" ¡¡ ERROR - No se pudo crear el cliente !!");
            }

            //TEST 2: Buscar un Cliente por ID (existente)
            System.out.println("\n>>> Test 2: Buscando cliente por ID " + nuevoCliente.getIdCliente() + "...");
            Cliente clienteEncontrado = clienteRepository.findById(nuevoCliente.getIdCliente());
            if(clienteEncontrado!=null){
                System.out.println(" ## Cliente encontrado: " + clienteEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el cliente con el ID " + nuevoCliente.getIdCliente());
            }

            //TEST 3: Buscar un Cliente por ID (inexistente)
            System.out.println("\n>>> Test 3: Buscando Cliente con ID 999 (inexistente)");
            Cliente clienteNoEncontrado = clienteRepository.findById(999);
            if(clienteNoEncontrado != null){
                System.out.println(" ## Cliente encontrado: " + clienteNoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró alumno con ID 999 !!");
            }

            //Test 4: Actualizar un Cliente
            System.out.println("\n>>> Test 4: Actualizando Cliente " + nuevoCliente.getIdCliente() + "...");
            nuevoCliente.setNombre("Ricardo Horacio"); //cambia el nombre del cliente recién creado
            int filasAfectadas = clienteRepository.update(nuevoCliente);
            if(filasAfectadas==1){
                System.out.println(" ## Cliente " + nuevoCliente.getIdCliente() + "actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + clienteRepository.findById(nuevoCliente.getIdCliente()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar al cliente !!");
            }

            //Test 5: Listar todos los clientes
            System.out.println("\n>>> Test 5: Listando todos los clientes...");
            List<Cliente> clientesTodos = clienteRepository.findAll();
            if(!clientesTodos.isEmpty()){
                System.out.println(" ## Clientes encontrados: " + clientesTodos.size());
                clientesTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron clientes");
            }

            //Test 6: Eliminar un cliente
            System.out.println("\n>>> Test 6: Eliminando Cliente " + nuevoCliente.getIdCliente() + "...");
            int filasAfectadasDelete = clienteRepository.delete(nuevoCliente.getIdCliente());
            if(filasAfectadasDelete==1){
                System.out.println(" ## Cliente " + nuevoCliente.getIdCliente() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + clienteRepository.findById(nuevoCliente.getIdCliente()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar al cliente !!");
            }

             //Pruebas para facturas
            
            //Test 7: Crear una nueva factura
            System.out.println("\n>>> Test 7: creando una nueva Factura...");
            Factura nuevaFactura = new Factura("A", 2 , 2024-15-04,7800.50, 4);
            facturaRepository.create(nuevaFactura);
            if(nuevaFactura.getNumero()>0 && nuevaFactura.getLetra()!=null){
                System.out.println(" ## Factura creada correctamente con letra " + nuevaFactura.getLetra() +"numero: "+ nuevaFactura.getNumero());
                System.out.println(nuevaFactura);
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo crear la factura !!");
            }

            //Test 8: Buscar una factura por ID 
            System.out.println("\n>>> Test 8: buscando factura por Letra y numero " + nuevaFactura.getLetra() + nuevaFactura.getNumero()+ " ...");
            Factura facturaEncontrada = facturaRepository.findByIdLetraNumero(nuevaFactura.getLetra(),nuevaFactura.getNumero());
            if(facturaEncontrada!=null){
                System.out.println(" ## Curso encontrado: " + facturaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró el factura con letra y numero " + nuevaFactura.getLetra() + nuevaFactura.getNumero());
            }

            //Test 9: Listar todos las facturas
            System.out.println("\n>>> Test 9: listar todas los facturas");
            List<Factura> facturasTodas = facturaRepository.findAll();
            if(!facturasTodas.isEmpty()){
                System.out.println(" ## Facturas encontradas: " + facturasTodas.size());
                facturasTodas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron facturas !!");
            }

            //Test 10: Buscar facturas por fecha
            System.out.println("\n>>> Test 10: buscando facturas por fecha");
            List<Factura> facturasPorFecha = facturaRepository.findByFecha();
            if(!facturasPorFecha.isEmpty()){
                System.out.println(" ## Facturas encontradas: " + facturasPorFecha.size());
                facturasPorFecha.forEach(System.out::println);
            } else{
                System.out.println(" ¡¡ No se encontraron cursos para LUNES por la MAÑANA");
                //no necesariamente es un error que no haya cursos
            }

            //Test 11: Actualizar una factura
            System.out.println("\n>>> Test 11: Actualizando factura " + nuevaFactura.getLetra() + nuevaFactura.getNumero() + " ...");
            nuevaFactura.setPrecioFinal(11700.00);
            nuevaFactura.setIdCliente(2);
            int filasAfectadasFactura = facturaRepository.update(nuevaFactura);
            if(filasAfectadasFactura==1){
                System.out.println(" ## Factura " + nuevaFactura.getLetra() +nuevaFactura.getIdCliente()+ " actualizado correctamente.");
                System.out.println("Verificando actualización: " + facturaRepository.findByIdLetraNumero(nuevaFactura.getLetra(), nuevaFactura.getNumero()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo actualizar la factura !!");
            }

             
            
        }


   }
}
