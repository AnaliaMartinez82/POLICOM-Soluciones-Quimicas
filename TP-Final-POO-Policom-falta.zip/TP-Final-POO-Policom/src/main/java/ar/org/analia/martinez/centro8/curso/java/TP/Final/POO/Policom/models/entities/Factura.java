package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities;

import java.time.LocalDate;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.Letra;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Factura {
   /* create table facturas(
      letra enum('A','B','C','E'),
      numero int,
      fecha date not null,
      precioFinal double not null,
      idCliente int not null,
      primary key(letra, numero)
      );
    */

    private Letra letra;
    private Integer numero;
    private LocalDate fecha;
    private double precioFinal;
    private Integer idCliente;
}
