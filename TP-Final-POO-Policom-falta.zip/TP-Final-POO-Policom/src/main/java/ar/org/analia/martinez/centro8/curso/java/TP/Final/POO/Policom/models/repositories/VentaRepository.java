package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Venta;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.Letra;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_VentaRepository;

@Repository
public class VentaRepository implements I_VentaRepository {

    /* private Letra letra;
     private Integer numero;
     private Integer idProducto;
     private Integer cantidad;
     private double subtotal; */

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO ventas (letra, numero, idProducto, cantidad, subtotal) VALUES (?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM ventas WHERE letra=?, numero=?, idProducto=?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM ventas";
    private static final String SQL_UPDATE =
        "UPDATE ventas SET cantidad=?, subtotal=? WHERE letra=?, numero=?, idProducto=?";
    private static final String SQL_DELETE =
        "DELETE FROM ventas WHERE letra=?, numero=?, idProducto=?";
   

    public VentaRepository(DataSource dataSource){
        this.dataSource=dataSource;
    }

     @Override
    public void create(Venta venta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE)) {
            ps.setString(1, venta.getLetra().name());             
            ps.setInt(2, venta.getNumero());
            ps.setInt(3,venta.getIdProducto());
            ps.setInt(4, venta.getCantidad());
            ps.setDouble(5, venta.getSubtotal());
            ps.executeUpdate();
            
        }
    }

    @Override
    public Venta findById(Letra letra, int numero, int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setString(1, letra.name());
            ps.setInt(2, numero);   
            ps.setInt(3, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            } 
        } 
        return null;
    }

    @Override
    public List<Venta> findAll() throws SQLException {
        List<Venta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while(rs.next()){
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(Venta venta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setInt(1, venta.getCantidad());
            ps.setDouble(2, venta.getSubtotal());
            ps.setString(3, venta.getLetra().name());             
            ps.setInt(4, venta.getNumero());
            ps.setInt(5,venta.getIdProducto());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public int delete(Letra letra, int numero,int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setString(1,letra.name());             
            ps.setInt(2, numero);    
            ps.setInt(3, idProducto);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    private Venta mapRow(ResultSet rs) throws SQLException{
        Venta v = new Venta();
        v.setLetra(Letra.valueOf(rs.getString("letra")));
        v.setNumero(rs.getInt("numero"));
        v.setIdProducto(rs.getInt("idProducto"));
        v.setCantidad(rs.getInt("cantidad"));
        v.setSubtotal(rs.getDouble("subtotal"));
        return v; 
    }

}
