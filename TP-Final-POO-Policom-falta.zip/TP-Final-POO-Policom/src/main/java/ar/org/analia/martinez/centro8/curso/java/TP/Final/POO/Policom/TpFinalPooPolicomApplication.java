package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpFinalPooPolicomApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpFinalPooPolicomApplication.class, args);
	}

}
