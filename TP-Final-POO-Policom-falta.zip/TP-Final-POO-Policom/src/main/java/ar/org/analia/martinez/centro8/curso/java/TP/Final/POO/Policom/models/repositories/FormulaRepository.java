package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Formula;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_FormulaRepository;

@Repository
public class FormulaRepository implements I_FormulaRepository{
    
    /*private Integer idMateriaPrima;
      private Integer idProducto;
      private double porcentajeDeMateriaPrimaEnElProducto; */
    
    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO formulas (porcentajeDeMateriaPrimaEnELProducto) VALUES (?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM formulas WHERE idMateriaPrima=? and idProducto=?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM formulas";
    private static final String SQL_UPDATE =
        "UPDATE formulas SET porcentajeDeMateriaPrimaEnElProducto=? WHERE idMateriaPrima=? and idProducto=?";
    private static final String SQL_DELETE =
        "DELETE FROM formulas WHERE idMateriaPrima=? and idProducto=?";
    private static final String SQL_FIND_BY_PORCENTAJE_DE_MATERIA_PRIMA_EN_EL_PRODUCTO =
        "SELECT * FROM formulas WHERE porcentajeDeMateriaPrimaEnElProducto=?";

    public FormulaRepository(DataSource dataSource){
        this.dataSource=dataSource;
    }

    @Override
    public void create(Formula formula) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setDouble(1, formula.getPorcentajeDeMateriaPrimaEnElProducto());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if(keys.next()){
                    formula.setIdMateriaPrima(keys.getInt(1));
                    formula.setIdProducto(keys.getInt(2));
                }
            } 
        }
    }

    @Override
    public Formula findById(int idMateriaPrima, int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idMateriaPrima);
            ps.setInt(2, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            } 
        } 
        return null;
    }

    @Override
    public List<Formula> findAll() throws SQLException {
        List<Formula> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while(rs.next()){
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(Formula formula) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setDouble(1, formula.getPorcentajeDeMateriaPrimaEnElProducto());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public int delete(int idMateriaPrima, int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
             ps.setInt(1, idMateriaPrima);
             ps.setInt(2, idProducto);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<Formula> findByPorcentajeDeMateriaPrimaEnElProducto(double porcentajeDeMateriaPrimaEnElProducto) throws SQLException {
        List<Formula> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_PORCENTAJE_DE_MATERIA_PRIMA_EN_EL_PRODUCTO)) {
            ps.setDouble(1, porcentajeDeMateriaPrimaEnElProducto);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
    }

    private Formula mapRow(ResultSet rs) throws SQLException{
        Formula fo = new Formula();
        fo.setIdMateriaPrima(rs.getInt("idMateriaPrima"));
        fo.setIdProducto(rs.getInt("idProducto"));
        fo.setPorcentajeDeMateriaPrimaEnElProducto(rs.getDouble("porcentajeDeMateriaPrimaEnElProducto"));
        return fo; 
    }

}
