package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.ProductoCosto;

public interface I_ProductoCostoRepository {

     void create(ProductoCosto productoCosto) throws SQLException;
     ProductoCosto findById(int idProducto) throws SQLException;
     List<ProductoCosto> findAll() throws SQLException;
     int update(ProductoCosto productoCosto) throws SQLException;
     int delete(int idProducto) throws SQLException;
     List<ProductoCosto> findByPresentacionCantidad(double presentacionCantidad) throws SQLException;

}
