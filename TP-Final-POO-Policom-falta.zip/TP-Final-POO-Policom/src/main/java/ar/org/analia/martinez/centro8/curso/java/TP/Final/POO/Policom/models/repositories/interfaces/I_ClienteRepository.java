package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Cliente;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.TipoCliente;

public interface I_ClienteRepository {

    void create(Cliente cliente) throws SQLException;
    Cliente findById(int idCliente) throws SQLException;
    List<Cliente> findAll() throws SQLException;
    int update(Cliente cliente) throws SQLException;
    int delete(int idCliente) throws SQLException;
    List<Cliente> findByTipoCliente(TipoCliente tipoCliente) throws SQLException;

}
