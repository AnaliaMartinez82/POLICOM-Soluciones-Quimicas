package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.ProductoCosto;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_ProductoCostoRepository;

@Repository
public class ProductoCostoRepository implements I_ProductoCostoRepository {

    /* 
    private Integer idProducto;
    private String nombreProducto;
    private double tiempoDeProduccionEnHoras;
    private double precioPorHora;
    private double precioTiempoTotal;
    private double valorEnvase;
    private double presentacionCantidad;
    private double precioCostoTotal;
    private double precioVenta; */

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO ProductoCostos (nombreProducto, tiempoProduccionEnHoras, PrecioPorHora, valorEnvase, presentacionCantidad, precioCostoTotal, precioVenta) VALUES (?,?,?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM productoCostos WHERE idProducto=?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM productoCostos";
    private static final String SQL_UPDATE =
        "UPDATE productoCostos SET nombreProducto=?, tiempoProduccionEnHoras=?, PrecioPorHora=?, valorEnvase=?, presentacionCantidad=?, precioCostoTotal=?, precioVenta=? WHERE idProducto=?";
    private static final String SQL_DELETE =
        "DELETE FROM productoCostos WHERE idProducto=?";
    private static final String SQL_FIND_BY_PRESENTACION_CANTIDAD =
        "SELECT * FROM productoCostos WHERE presentacionCantidad=?";

    public ProductoCostoRepository(DataSource dataSource){
        this.dataSource=dataSource;
    }

    @Override
    public void create(ProductoCosto productoCosto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, productoCosto.getNombreProducto());
            ps.setDouble(2, productoCosto.getTiempoDeProduccionEnHoras());
            ps.setDouble(3, productoCosto.getPrecioPorHora());
            ps.setDouble(4, productoCosto.getValorEnvase());
            ps.setDouble(5, productoCosto.getPresentacionCantidad());
            ps.setDouble(6, productoCosto.getPrecioCostoTotal());
            ps.setDouble(7, productoCosto.getPrecioVenta());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if(keys.next()){
                    productoCosto.setIdProducto(keys.getInt(1));
                }
            } 
        }
    }

    @Override
    public ProductoCosto findById(int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            } 
        } 
        return null;
    }

    @Override
    public List<ProductoCosto> findAll() throws SQLException {
        List<ProductoCosto> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while(rs.next()){
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(ProductoCosto productoCosto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, productoCosto.getNombreProducto());
            ps.setDouble(2, productoCosto.getTiempoDeProduccionEnHoras());
            ps.setDouble(3, productoCosto.getPrecioPorHora());
            ps.setDouble(4, productoCosto.getValorEnvase());
            ps.setDouble(5, productoCosto.getPresentacionCantidad());
            ps.setDouble(6, productoCosto.getPrecioCostoTotal());
            ps.setDouble(7, productoCosto.getPrecioVenta());
            ps.setInt(6, productoCosto.getIdProducto());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public int delete(int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idProducto);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<ProductoCosto> findByPresentacionCantidad(double presentacionCantidad) throws SQLException {
        List<ProductoCosto> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_PRESENTACION_CANTIDAD)) {
            ps.setDouble(1, presentacionCantidad);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
    }

    private ProductoCosto mapRow(ResultSet rs) throws SQLException{
        ProductoCosto p = new ProductoCosto();
        p.setIdProducto(rs.getInt("idProducto"));
        p.setNombreProducto(rs.getString("nombreProducto"));
        p.setTiempoDeProduccionEnHoras(rs.getDouble("tiempoProduccionEnHoras"));
        p.setPrecioPorHora(rs.getDouble("PrecioPorHora"));
        p.setValorEnvase(rs.getDouble("valorEnvase"));
        p.setPresentacionCantidad(rs.getDouble("presentacionCantidad"));
        p.setPrecioCostoTotal(rs.getDouble("precioCostoTotal"));
        p.setPrecioVenta(rs.getDouble("precioVenta"));
        return p; 
    }

}
