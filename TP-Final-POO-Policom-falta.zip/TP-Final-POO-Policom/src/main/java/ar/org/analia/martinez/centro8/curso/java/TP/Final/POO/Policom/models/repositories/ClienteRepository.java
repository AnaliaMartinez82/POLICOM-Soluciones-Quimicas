package ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.entities.Cliente;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.enums.TipoCliente;
import ar.org.analia.martinez.centro8.curso.java.TP.Final.POO.Policom.models.repositories.interfaces.I_ClienteRepository;

@Repository
public class ClienteRepository implements I_ClienteRepository {

    private final DataSource DATASOURCE;

    //  private int idCliente;
    //  private String nombre;
    //  private TipoCliente tipoCliente;
    //  private String cuit;
    //  private String dni;
    //  private String email;
    //  private String telefono;
    //  private String direccion;

    //Representan consultas SQL.
    private static final String SQL_CREATE =
        "INSERT INTO clientes(nombre, tipoCliente, cuit, dni, email,telefono, direccion) VALUES (?,?,?,?,?,?,?)";
    //los signos de pregunta son marcadores de posición para los valores que se establecerán
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM clientes WHERE idCliente=?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM clientes";
    private static final String SQL_UPDATE =
        "UPDATE clientes SET nombre=?, tipoCliente=?, cuit=?, dni=?, email=?,telefono=?, direccion=? WHERE idCliente=?";
    private static final String SQL_DELETE =
        "DELETE FROM clientes WHERE id=?";
    private static final String SQL_FIND_BY_TIPO_CLIENTE =
        "SELECT * FROM clientes WHERE tipoCliente=?";

    public ClienteRepository(DataSource dataSource){
        this.DATASOURCE = dataSource;
    }
    // de esta manera, el repositorio queda configurado con la fuente de conexiones
    //que usará siempre, el repositorio no crea su propio datasource, sino que se le proporciona
    //uno configurado con HikariCP

    
    @Override
    public void create(Cliente cliente) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) { //obtenemos la conexión
            //PreparedStatement es una interfaz de Java, Sirve para ejecutar consultas SQL de forma segura y eficiente.

            ps.setString(1, cliente.getNombre()); //el 1 se refiere a la primera posición del ?  
            ps.setString(2, cliente.getTipoCliente().name());
            ps.setString(3, cliente.getCuit());
            ps.setString(4, cliente.getDni());
            ps.setString(5, cliente.getEmail());
            ps.setString(6, cliente.getTelefono());
            ps.setString(7, cliente.getDireccion());
            ps.executeUpdate(); //ejecuta la sentencia SQL_INSERT. Para sentencias que modifican
            //datos (INSERT, UPDATE y DELETE), se utiliza executeUpdate()
            try (ResultSet keys = ps.getGeneratedKeys()) { //recupera las claves autogeneradas
                //ResultSet es una interfaz en JDBC que representa un conjunto de resultados de una consulta sql.
                if(keys.next()){
                    cliente.setIdCliente(keys.getInt(1)); //le inserta el id que devolvió el RETURN_GENERATED_KEYS
                }                
            }  
        }
    }

    @Override
    public Cliente findById(int idCliente) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) { //ejecuta la consulta SQL (SELECT)
                //para consultas que devuelven datos, se utiliza executeQuery() que retorna
                //un ResultSet con los resultados de la consulta
                if(rs.next()){
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Cliente> findAll() throws SQLException {
        List<Cliente> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(Cliente cliente) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, cliente.getNombre()); //el 1 se refiere a la primera posición del ?  
            ps.setString(2, cliente.getTipoCliente().name());
            ps.setString(3, cliente.getCuit());
            ps.setString(4, cliente.getDni());
            ps.setString(5, cliente.getEmail());
            ps.setString(6, cliente.getTelefono());
            ps.setString(7, cliente.getDireccion());
            ps.setInt(8, cliente.getIdCliente());
            int filasAfectadas = ps.executeUpdate(); //almacena el resultado de la ejecución
            return filasAfectadas; //devuelve el número de filas afectadas
        }
    }

    @Override
    public int delete(int idCliente) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idCliente);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<Cliente> findByTipoCliente(TipoCliente tipoCliente) throws SQLException {
        List<Cliente> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_TIPO_CLIENTE)) {
            ps.setString(1, tipoCliente.name());
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
    }


    // lógica de mapeo de ResultSet a objeto Java,

    private Cliente mapRow(ResultSet rs) throws SQLException{
        //toma una fila de resultados de la BD y la convierte en un objeto del tipo Cliente
        Cliente c = new Cliente();
        c.setIdCliente(rs.getInt("idCliente"));
        c.setNombre(rs.getString("nombre"));
        c.setTipoCliente(TipoCliente.valueOf(rs.getString("tipo de cliente")));
        c.setCuit(rs.getString("cuit"));
        c.setDni(rs.getString("dni"));
        c.setEmail(rs.getString("email"));
        c.setTelefono(rs.getString("telefono"));
        c.setDireccion(rs.getString("direccion"));
        return c;

    }

}
